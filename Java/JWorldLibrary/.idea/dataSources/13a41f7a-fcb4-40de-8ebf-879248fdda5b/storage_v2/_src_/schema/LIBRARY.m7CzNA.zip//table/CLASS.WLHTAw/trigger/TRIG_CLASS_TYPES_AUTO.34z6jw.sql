create trigger TRIG_CLASS_TYPES_AUTO
    before insert
    on CLASS
    for each row
declare
begin
    select seq_class_types_auto.nextval into :new.classno from dual;
end trig_class_types_auto;
/

