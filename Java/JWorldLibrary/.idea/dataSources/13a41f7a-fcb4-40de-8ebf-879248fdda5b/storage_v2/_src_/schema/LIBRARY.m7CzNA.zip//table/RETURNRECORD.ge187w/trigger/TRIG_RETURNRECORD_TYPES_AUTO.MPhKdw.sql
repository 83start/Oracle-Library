create trigger TRIG_RETURNRECORD_TYPES_AUTO
    before insert
    on RETURNRECORD
    for each row
declare
begin
    select seq_returnrecord_types_auto.nextval into :new.retno from dual;
end trig_returnrecord_types_auto;
/

