create trigger TRIG_PRESS_TYPES_AUTO
    before insert
    on PRESS
    for each row
declare
begin
    select seq_press_types_auto.nextval into :new.preno from dual;
end trig_press_types_auto;
/

