create trigger TRIG_STUDENT_TYPES_AUTO
    before insert
    on STUDENT
    for each row
declare
begin
    select seq_student_types_auto.nextval into :new.stuno from dual;
end trig_student_types_auto;
/

