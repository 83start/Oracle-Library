create trigger STU_SEX_TRI
    before insert or update
    on STUDENT
    for each row
BEGIN
  IF(:NEW.sex not in['男','女'])THEN
     RAISE_APPLICATION_ERROR(-20008,'性别输入不合法');
  END IF;
END stu_sex_tri;
/

