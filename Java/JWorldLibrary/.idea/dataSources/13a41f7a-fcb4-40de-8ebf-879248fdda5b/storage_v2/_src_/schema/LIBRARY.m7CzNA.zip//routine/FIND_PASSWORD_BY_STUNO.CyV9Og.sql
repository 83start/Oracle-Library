create FUNCTION FIND_PASSWORD_BY_STUNO (P_NO IN NUMBER,P_ANSWER IN VARCHAR2)RETURN STUDENT.STUPASSWORD%TYPE
  IS
    V_PASSWORD STUDENT.STUPASSWORD%TYPE;
  BEGIN
    SELECT STUPASSWORD
    INTO V_PASSWORD
    FROM STUDENT
    WHERE STUNO = P_NO AND P_ANSWER = (
                                            SELECT STUPASSWORDANSWER 
                                            FROM STUDENT
                                            WHERE STUNO = P_NO
                                          );
    RETURN V_PASSWORD;
  EXCEPTION 
    WHEN NO_DATA_FOUND THEN
     RETURN '查无此人';
  END FIND_PASSWORD_BY_STUNO;
/

