create package PRESS_PACKAGE is

  -- Author  : CJ
  -- Created : 2021/1/2 15:40:58
  -- Purpose : 出版社的存储函数和过程
  -- 指定出版社的所有的图书
  FUNCTION COUNT_PRESS_BOOK_NUMBER(V_PRENO IN OUT NUMBER)RETURN VARCHAR2;
  
  -- 通过出版社的名字来找出版社的姓名
  FUNCTION FIND_PRENO_BY_PRENAME (V_NAME IN VARCHAR2)RETURN NUMBER;
  
  -- 插入新的出版社信息
  PROCEDURE INSERT_INTO_PRESS
(
	V_NAME IN VARCHAR2,
	V_NO OUT NUMBER
);

end PRESS_PACKAGE;
/

