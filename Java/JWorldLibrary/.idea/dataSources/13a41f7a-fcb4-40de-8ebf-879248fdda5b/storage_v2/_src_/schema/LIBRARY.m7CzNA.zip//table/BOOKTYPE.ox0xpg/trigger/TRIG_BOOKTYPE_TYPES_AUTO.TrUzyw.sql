create trigger TRIG_BOOKTYPE_TYPES_AUTO
    before insert
    on BOOKTYPE
    for each row
declare
begin
    select seq_booktype_types_auto.nextval into :new.typeno from dual;
end trig_booktype_types_auto;
/

