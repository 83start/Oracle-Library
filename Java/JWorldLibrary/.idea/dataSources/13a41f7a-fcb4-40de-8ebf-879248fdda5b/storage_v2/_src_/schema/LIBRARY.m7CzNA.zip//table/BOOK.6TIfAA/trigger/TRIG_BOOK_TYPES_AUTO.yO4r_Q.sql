create trigger TRIG_BOOK_TYPES_AUTO
    before insert
    on BOOK
    for each row
declare
begin
    select seq_book_types_auto.nextval into :new.bookno from dual;
end trig_book_types_auto;
/

