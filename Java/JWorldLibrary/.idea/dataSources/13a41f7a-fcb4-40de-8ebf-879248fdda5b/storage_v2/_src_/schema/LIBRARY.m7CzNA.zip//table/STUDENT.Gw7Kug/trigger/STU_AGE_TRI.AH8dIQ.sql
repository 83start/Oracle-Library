create trigger STU_AGE_TRI
    before insert or update
    on STUDENT
    for each row
BEGIN
  IF(:NEW.age<0 or :NEW >110)THEN
     RAISE_APPLICATION_ERROR(-20010,'年龄输入不合法');
  END IF;
END stu_age_tri;
/

