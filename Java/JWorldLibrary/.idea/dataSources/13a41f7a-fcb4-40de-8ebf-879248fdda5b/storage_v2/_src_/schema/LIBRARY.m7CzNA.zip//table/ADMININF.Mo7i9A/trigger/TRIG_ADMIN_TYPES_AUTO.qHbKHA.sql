create trigger TRIG_ADMIN_TYPES_AUTO
    before insert
    on ADMININF
    for each row
declare
begin
    select seq_admin_types_auto.nextval into :new.admno from dual;
end trig_admin_types_auto;
/

