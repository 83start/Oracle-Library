create trigger TRIG_AUTHOR_TYPES_AUTO
    before insert
    on AUTHOR
    for each row
declare
begin
    select seq_author_types_auto.nextval into :new.autno from dual;
end trig_author_types_auto;
/

