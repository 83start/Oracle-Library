create trigger TRIG_TICKET_TYPES_AUTO
    before insert
    on TICKET
    for each row
declare
begin
    select seq_ticket_types_auto.nextval into :new.ticno from dual;
end trig_ticket_types_auto;
/

