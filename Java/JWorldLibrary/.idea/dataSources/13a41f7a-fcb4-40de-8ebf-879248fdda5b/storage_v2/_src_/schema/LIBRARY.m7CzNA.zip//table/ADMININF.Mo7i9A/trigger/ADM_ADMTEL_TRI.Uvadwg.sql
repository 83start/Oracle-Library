create trigger ADM_ADMTEL_TRI
    before insert or update
    on ADMININF
    for each row
BEGIN
  IF(length(:NEW.admtel)<>11)THEN
     RAISE_APPLICATION_ERROR(-20008,'电话号码的位数为11位');
  END IF;
END adm_admtel_tri;
/

