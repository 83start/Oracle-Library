create trigger STU_STUTEL_TRI
    before insert or update
    on STUDENT
    for each row
BEGIN
  IF(length(:NEW.stutel)<>11)THEN
     RAISE_APPLICATION_ERROR(-20007,'电话号码的位数为11位');
  END IF;
END stu_stutel_tri;
/

