create trigger STU_IDCARD_TRI
    before insert or update
    on STUDENT
    for each row
BEGIN
  IF(length(:NEW.IDCARD)<>18)THEN
     RAISE_APPLICATION_ERROR(-20004,'身份证的位数为18位。');
  END IF;
END stu_idCard_tri;
/

