create trigger TRIG_BORROWRECORD_TYPES_AUTO
    before insert
    on BORROWRECORD
    for each row
declare
begin
    select seq_borrowrecord_types_auto.nextval into :new.BORRNO from dual;
end trig_borrowrecord_types_auto;
/

