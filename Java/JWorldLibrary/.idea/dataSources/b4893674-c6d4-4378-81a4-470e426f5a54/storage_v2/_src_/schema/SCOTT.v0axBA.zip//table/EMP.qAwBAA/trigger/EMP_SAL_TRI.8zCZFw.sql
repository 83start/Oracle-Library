create trigger EMP_SAL_TRI
    before insert or update
    on EMP
    for each row
DECLARE
  PRAGMA AUTONOMOUS_TRANSACTION;--没有这句话就会触发异常

BEGIN
  -- :NEW 是新插入的值
  IF(:new.sal<0)THEN
     RAISE_APPLICATION_ERROR(-20002,'插入的工资值不能低于0');
  END IF;
  IF(:new.sal > max_sal_fun*2)THEN
     RAISE_APPLICATION_ERROR(-20003,'插入的工资值不能高于最高工资的两倍');
  END IF;         
END;

/

