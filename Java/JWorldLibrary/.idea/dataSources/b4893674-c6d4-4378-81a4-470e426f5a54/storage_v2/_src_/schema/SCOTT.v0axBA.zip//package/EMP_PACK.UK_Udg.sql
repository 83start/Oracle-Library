create PACKAGE emp_pack IS
  PROCEDURE dept_pro;
  procedure update_sal2(p_no IN emp.empno%type,p_sal in emp.sal%type,p_result out varchar2);
  FUNCTION find_name_by_no(p_no emp.empno%type) RETURN emp.ename%type;
END;

/

