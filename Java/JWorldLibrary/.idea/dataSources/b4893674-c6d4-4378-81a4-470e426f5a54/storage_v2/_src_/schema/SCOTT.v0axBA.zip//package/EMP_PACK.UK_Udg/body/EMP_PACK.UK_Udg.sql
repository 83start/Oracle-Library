create PACKAGE BODY emp_pack
IS

PROCEDURE dept_pro
IS
  CURSOR dept_cur IS SELECT * FROM dept;
BEGIN
  FOR v_dept IN dept_cur LOOP
     DBMS_OUTPUT.PUT_LINE(dept_cur%ROWCOUNT ||'  '||v_dept.deptno||'  '||v_dept.dname||'  '||v_dept.loc);
  END LOOP;
END;

procedure update_sal2(
       p_no IN emp.empno%type,
       p_sal in emp.sal%type,
       p_result out varchar2
)
is
       v_sal emp.sal%type;
begin
  select sal
  into v_sal
  from emp
  where empno = p_no;

  if p_sal > v_sal then
    update emp set sal = p_sal
    where empno= p_no;
    p_result:='OK';
  elsif p_sal < v_sal then
    p_result:='NO';
  end if;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    p_result:='没有这个人';
end update_sal2;

FUNCTION find_name_by_no(p_no emp.empno%type)
RETURN emp.ename%type -- varchar
IS
       v_name emp.ename%type;
BEGIN
  SELECT ename
  INTO v_name
  FROM emp
  WHERE empno = p_no;
  RETURN v_name;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN '查无此人';
END find_name_by_no;

END emp_pack;


/

