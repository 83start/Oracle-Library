create procedure DEPT_LOC_PRO(
p_no in emp.empno%type,
p_loc out dept.loc%type
) 

is
begin
  select loc into p_loc from dept
  where deptno = (select deptno from emp where empno =p_no);
end DEPT_LOC_PRO;
/

