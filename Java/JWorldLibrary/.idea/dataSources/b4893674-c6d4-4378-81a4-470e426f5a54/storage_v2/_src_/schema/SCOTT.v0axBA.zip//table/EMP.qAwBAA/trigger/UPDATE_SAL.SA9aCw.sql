create trigger UPDATE_SAL
    before update
    on EMP
    for each row
    when (new.sal < old.sal and old.job = 'SALESMAN')
begin
    raise_application_error(-20004,'除销售员外，雇员工资只增不减');--阻拦发生
end ;
/

