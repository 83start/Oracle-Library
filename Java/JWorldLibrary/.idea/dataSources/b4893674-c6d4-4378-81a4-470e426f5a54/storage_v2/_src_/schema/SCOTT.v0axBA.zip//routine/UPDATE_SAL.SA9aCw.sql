create procedure update_sal(
       p_no IN emp.empno%type,
       p_sal in emp.sal%type,
       p_result out varchar
)
is
       v_sal emp.sal%type;
begin
  -- 
  select sal 
  into v_sal
  from emp 
  where empno = p_no;
  
  if p_sal > v_sal then
    update emp set sal = p_sal
    where empno= p_no;
    p_result:='数据更新成功';
  elsif p_sal < v_sal then
    p_result:='工资小于原来是工资，更新失败';
  end if;
  
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    p_result:='查无此人';
end update_sal;


/

