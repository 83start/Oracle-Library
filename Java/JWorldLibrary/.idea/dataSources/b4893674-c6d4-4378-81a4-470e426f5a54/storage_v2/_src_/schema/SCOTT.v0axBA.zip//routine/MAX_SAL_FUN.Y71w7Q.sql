create function max_sal_fun
return emp.sal%type
  is
   v_max_sal emp.sal%type;
begin
  select max(sal) into v_max_sal from emp;
  return v_max_sal;
end max_sal_fun;
/

