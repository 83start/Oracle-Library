create FUNCTION find_name_by_no(p_no emp.empno%type)
RETURN emp.ename%type -- varchar
IS
       v_name emp.ename%type;
BEGIN
  SELECT ename
  INTO v_name
  FROM emp
  WHERE empno = p_no;
  RETURN v_name;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN '查无此人';
END find_name_by_no;

/

