create function hellow2_world(v_logo in emp.ENAME%type)
return varchar2
is
begin
	dbms_output.put_line('helloWorld');
	return v_logo;
end;
/

